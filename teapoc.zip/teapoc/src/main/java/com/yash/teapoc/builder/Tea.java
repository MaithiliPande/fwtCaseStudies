package com.yash.teapoc.builder;

public class Tea {

	private int milk;
	private int water;
	private int tea;
	private int sugar;

	private Tea(Builder builder) {
		this.milk = builder.milk;
		this.water = builder.water;
		this.tea = builder.tea;
		this.sugar = builder.sugar;
	}

	public static class Builder {
		private TeaConfiguration teaConfiguration;
		private int milk;
		private int water;
		private int tea;
		private int sugar;

		
		public Builder(TeaConfiguration teaConfig) {
			this.teaConfiguration = teaConfig;
		}

		public Builder addmilk() {
			this.milk = teaConfiguration.getMilk();
			return this;
		}

		public Builder addWater() {
			this.water = teaConfiguration.getWater();
			return this;
		}

		public Builder addTea() {
			this.tea = teaConfiguration.getTea();
			return this;
		}

		public Builder addSugar() {
			this.sugar = teaConfiguration.getSugar();
			return this;
		}

		public Tea makeTea() {
			return new Tea(this);
		}
	}

	@Override
	public String toString() {
		return "Tea [milk=" + milk + ", water=" + water + ", tea=" + tea + ", sugar=" + sugar + "]";
	}
	
	
	
}
