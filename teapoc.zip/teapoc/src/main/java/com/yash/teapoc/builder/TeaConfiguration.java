package com.yash.teapoc.builder;

public class TeaConfiguration {
	
	private int milk = 40;
	private int water = 60;
	private int tea = 5;
	private int sugar = 15;
	
	public int getMilk() {
		return milk;
	}
	public int getWater() {
		return water;
	}
	public int getTea() {
		return tea;
	}
	public int getSugar() {
		return sugar;
	}
	public void setMilk(int milk) {
		this.milk = milk;
	}
	public void setWater(int water) {
		this.water = water;
	}
	public void setTea(int tea) {
		this.tea = tea;
	}
	public void setSugar(int sugar) {
		this.sugar = sugar;
	}
	
	

}
