package com.yash.teapoc.builder;

public class TeaTest {

	public static void main(String[] args) {
		TeaConfiguration teaConfig = new TeaConfiguration();
		Tea tea = new Tea.Builder(teaConfig)
						.addmilk()
						.addWater()
						.addTea()
						.addSugar()
						.makeTea();
		System.out.println(tea);

	}

}
