import java.util.Arrays;

public class InsertionSort {

	public static void main(String[] args) {
		int array[] = {5,1,12,-5,16};
		for(int i = 1; i<array.length-1; i++) {
			for(int j = i;j>0; j--) {
				swap(j,i,array);
			}
		}
		System.out.println("Sorted array : "+Arrays.toString(array));
	}

	private static void swap(int j, int i, int[] array) {
		if(array[j]<array[j-1]) {
			int temp = array[j];
			array[j] = array[j-1];
			array[j-1] = temp;
		}
	}

}
