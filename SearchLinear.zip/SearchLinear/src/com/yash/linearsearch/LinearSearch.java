package com.yash.linearsearch;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		Scanner input  = new Scanner(System.in);
		System.out.println("Enter an element to search : ");
		int element = input.nextInt();
		int array[] = {10,20,30,40,50};
		int result = searchElement(array,element); 
		if(result == -1) {
			System.out.println("Element is not found");
		}else {
			System.out.println("Element is found at poistion : "+result);
		}
		input.close();
	}

	private static int searchElement(int[] array, int element) {
		int position = -1;
		for(int i = 0; i<=array.length-1; i++) {
			if(array[i] == element) {
				return position = i;
			}
		}
		return position;
	}

}
