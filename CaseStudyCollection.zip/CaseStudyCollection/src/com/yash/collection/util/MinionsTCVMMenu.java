package com.yash.collection.util;

public class MinionsTCVMMenu 
{
	static String[] menu={new String("----------------Welcome To Minions-Tea-&-Coffee Vending Machine--------------------"),
					new String("Today's Menu"),
//					new String("1. Black Tea"),
//					new String("2. Tea"),
					new String("1. Black Coffee"),
					new String("2. Coffee"),
					new String("3. Refill Container"),
					new String("4. Check individual sale"),
					new String("5. Check Total Sale"),
					new String("6. Container status"),
					new String("0. Exit")
			};
	
	public static void showMenu()
	{
		for (String string : menu) 
		{
			System.out.println(string);
		}
	}

}
