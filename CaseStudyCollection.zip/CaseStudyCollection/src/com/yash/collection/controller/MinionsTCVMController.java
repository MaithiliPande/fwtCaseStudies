package com.yash.collection.controller;

import java.util.Scanner;

//import javax.swing.JOptionPane;

import com.yash.collection.pojo.MinionsTCVM;
import com.yash.collection.service.BlackCoffeeService;
//import com.yash.collection.service.BlackTeaService;
import com.yash.collection.service.CoffeeService;
//import com.yash.collection.service.TeaService;
import com.yash.collection.util.MinionsTCVMMenu;

public class MinionsTCVMController {
	Scanner scanner = new Scanner(System.in);
	MinionsTCVM minionsTCVM;
	// BlackTeaService blacktea;
	// TeaService tea;
	BlackCoffeeService blackcoffee;
	CoffeeService coffee;
	int choice;
	int noOfCups;
	int blackTeaCost = 0;
	int TeaCost = 0;
	int blackCoffeeCost = 0;
	int coffeeCost = 0;

	public MinionsTCVMController() {
		MinionsTCVM.refillContainers();
	}

	public void TCVMOperation() {
		do{
			MinionsTCVMMenu.showMenu();
			System.out.println("Enter your choice");
			choice = scanner.nextInt();

			switch (choice) {
			// case 1: {
			// System.out.println("Enter no. of cups");
			// noOfCups = scanner.nextInt();
			// blacktea = new BlackTeaService();
			// blackTeaCost=blacktea.makeBlackTea(noOfCups);
			// break;
			// }
			//
			// case 2: {
			// System.out.println("Enter no. of cups");
			// noOfCups = scanner.nextInt();
			// tea = new TeaService();
			// tea.makeTea(noOfCups);
			// break;
			// }

			case 1: {
				System.out.println("Enter no. of cups");
				noOfCups = scanner.nextInt();
				blackcoffee = new BlackCoffeeService();
				blackCoffeeCost = blackcoffee.makeBlackCoffee(noOfCups);
				break;
			}

			case 2: {
				System.out.println("Enter no. of cups");
				noOfCups = scanner.nextInt();
				coffee = new CoffeeService();
				coffeeCost = coffee.makeCoffee(noOfCups);
				break;
			}
			case 3: {
				MinionsTCVM.refillContainers();
				break;
			}
			case 4: {
				System.out.println("Black tea cost for the day: " + blackTeaCost);
				System.out.println("Tea cost for the day: " + TeaCost);
				System.out.println("Black coffee cost for the day: " + blackCoffeeCost);
				System.out.println("Coffee cost for the day: " + coffeeCost);

				break;
			}

			case 5: {
				System.out.println("Total sale: " + (blackTeaCost + TeaCost + blackCoffeeCost + coffeeCost));
			}
			case 6: {
				System.out.println(MinionsTCVM.getIngredients());
				break;
			}
			case 0: {
				System.exit(0);
				break;

			}
			default: {
				System.out.println("Invalid choice exit");
			}

			}
		}while(choice!=0);

	}

}
