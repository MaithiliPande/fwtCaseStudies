package com.yash.collection.service;

import java.util.HashMap;

import com.yash.collection.pojo.MinionsTCVM;
import com.yash.collection.util.TCQuantity;

public class CoffeeService {
	int coffeeRequiredQuantity;
	int waterRequiredQuantity;
	int sugarRequiredQuantity;
	int milkRequiredQuantity;

	int coffeeAvailableQuantity;
	int waterAvailableQuantity;
	int sugarAvailableQuantity;
	int milkavailableQuantity;

	static int coffeeCost = 0;

	public int makeCoffee(int noOfCups) {
		TCQuantity tcQuantity = new TCQuantity();
		coffeeRequiredQuantity = (tcQuantity.getIngredientsForCoffee().get("Coffee") * noOfCups);
		waterRequiredQuantity = (tcQuantity.getIngredientsForCoffee().get("Water") * noOfCups);
		sugarRequiredQuantity = (tcQuantity.getIngredientsForCoffee().get("Sugar") * noOfCups);
		milkRequiredQuantity = (tcQuantity.getIngredientsForCoffee().get("Milk") * noOfCups);
		
		coffeeAvailableQuantity=MinionsTCVM.getIngredients().get("Coffee");
		waterAvailableQuantity=MinionsTCVM.getIngredients().get("Water");
		sugarAvailableQuantity=MinionsTCVM.getIngredients().get("Sugar");
		milkavailableQuantity=MinionsTCVM.getIngredients().get("Milk");

		if ((coffeeAvailableQuantity > coffeeRequiredQuantity) && (waterAvailableQuantity > waterRequiredQuantity)
				&& (sugarAvailableQuantity > sugarRequiredQuantity) && (milkavailableQuantity > milkRequiredQuantity)) {

			HashMap<String, Integer> update = new HashMap<String, Integer>();
			update.put("Coffee", (coffeeAvailableQuantity - coffeeRequiredQuantity));
			update.put("Water", (waterAvailableQuantity - waterRequiredQuantity));
			update.put("Sugar", (sugarAvailableQuantity - sugarRequiredQuantity));
			update.put("Milk", (milkavailableQuantity - milkRequiredQuantity));
			System.out.println("Coffee prepared");
			MinionsTCVM.setIngredients(update);
			coffeeCost = coffeeCost + (noOfCups * 20);

		}

		System.out.println(MinionsTCVM.getIngredients());

		return coffeeCost;

	}

}
