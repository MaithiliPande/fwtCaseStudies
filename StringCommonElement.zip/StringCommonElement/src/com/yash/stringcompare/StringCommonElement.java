package com.yash.stringcompare;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringCommonElement {

	public static void main(String[] args) {
		String [] array1 = {"mango","apple","orange"};
		String [] array2 = {"apple","grapes","orange","mango"};
		String [] result = findCommonElements(array1, array2);
		System.out.println("Common Elements : "+Arrays.toString(result));
	}

	private static String[] findCommonElements(String[] array1, String[] array2) {
		List<String> list = new ArrayList<>();
		for(int i = 0; i <= array2.length-1; i++) {
			for(int j = 0 ;j<=array1.length-1;j++) {
				if(array2[i] == array1[j]) {
					list.add(array2[i]);
				}	
			}
		}
		return list.toArray(new String[list.size()]);
	}

}
