package com.yash.demo;

/**
 * configuration will be in gram and milli liter
 * @author masoom.badkur
 *
 */
public class TeaConfiguaration {
	//Consumption
	public static double TEA_CONSUMPTION = 5;
	public static double WATER_CONSUMPTION = 60;
	public static double MILK_CONSUMPTION = 40;
	public static double SUGAR_CONSUMPTION = 15;
	
	//Wastage
	public static double TEA_WASTAGE = 1;
	public static double WATER_WATAGE = 5;
	public static double MILK_WASTAGE = 4;
	public static double SUGAR_WASTAGE = 2;

}
