package com.yash.demo;

public class Tea {
	
	private double tea;
	private double milk;
	private double water;
	private double sugar;
	
	private Tea(TeaBuilder teaBuilder) {
		this.tea = teaBuilder.tea;
		this.milk = teaBuilder.milk;
		this.water = teaBuilder.water;
		this.sugar = teaBuilder.sugar;
	}
	
	public static class TeaBuilder {
		
		private double tea;
		private double milk;
		private double water;
		private double sugar;
		
		public TeaBuilder addTea() {
			
			this.tea = TeaConfiguaration.TEA_CONSUMPTION;
			return this;
		}
		
		public TeaBuilder addMilk() {
			
			this.milk = TeaConfiguaration.MILK_CONSUMPTION;
			
			return this;
		}
		
		public TeaBuilder addSugar() {
			this.sugar = TeaConfiguaration.SUGAR_CONSUMPTION;
			return this;
		}
		
		public TeaBuilder addWater() {
			this.water = TeaConfiguaration.WATER_CONSUMPTION;
			return this;
		}
		
		public Tea prepare() {			
			return new Tea(this);
		}
		
	}

	@Override
	public String toString() {
		return "Tea is ready with : [tea=" + tea + ", milk=" + milk + ", water=" + water + ", sugar=" + sugar + "]";
	}
}
