package com.yash.demo;

import java.util.ArrayList;
import java.util.List;

public class TeaServiceImpl {

	ContainerService containerService = new ContainerService();
	List<Container> containers = containerService.getContainerStatus();

	Tea prepareTea() {

		Tea tea = null;

		Container milkContainer1 = containerService.getContainerByName("milk");
		Container sugarContainer1 = containerService.getContainerByName("sugar");
		Container teaContainer1 = containerService.getContainerByName("tea");
		Container waterContainer1 = containerService.getContainerByName("water");

		if (checkMilkAvailability(milkContainer1) && checkSugarAvailability(sugarContainer1)
				&& checkTeaAvailability(teaContainer1) && checkWaterAvailability(waterContainer1)) {

			tea = new Tea.TeaBuilder().addMilk().addSugar().addTea().addWater().prepare();
			
			milkContainer1.setCurrentAvailability(milkContainer1.getCurrentAvailability()
					- (TeaConfiguaration.MILK_CONSUMPTION + TeaConfiguaration.MILK_WASTAGE));
		}

		return tea;

	}
	
	List<Container> getContainers() {
		return containers;
	}

	private boolean checkMilkAvailability(Container milkContainer1) {
		return milkContainer1.getCurrentAvailability() > TeaConfiguaration.MILK_CONSUMPTION;
	}

	private boolean checkSugarAvailability(Container sugarContainer1) {
		return sugarContainer1.getCurrentAvailability() > TeaConfiguaration.SUGAR_CONSUMPTION;
	}

	private boolean checkTeaAvailability(Container teaContainer1) {
		return teaContainer1.getCurrentAvailability() > TeaConfiguaration.TEA_CONSUMPTION;
	}

	private boolean checkWaterAvailability(Container waterContainer1) {
		return waterContainer1.getCurrentAvailability() > TeaConfiguaration.WATER_CONSUMPTION;
	}

}
