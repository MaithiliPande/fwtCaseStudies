package com.yash.demo;

import java.util.List;

public class TeaTest {

	public static void main(String[] args) {
		
		TeaServiceImpl teaServiceImpl = new TeaServiceImpl();
		
		Tea tea = teaServiceImpl.prepareTea();
		List<Container> containers = teaServiceImpl.getContainers();
		
		System.out.println(containers.size());
		
		for (Container container : containers) {
			System.out.println(container.getName() + ":  " + container.getCurrentAvailability() );
		}
		
		System.out.println(tea);
	}

}
