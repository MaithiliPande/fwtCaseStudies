package com.yash.demo;

import java.util.ArrayList;
import java.util.List;

public class ContainerService {
	
	List<Container> containers;
	
	public ContainerService() {
		containers = new ArrayList<>();
		
		containers.add(new Container("milk", 10000, 10000, false));
		containers.add(new Container("tea", 2000, 2000, false));
		containers.add(new Container("water", 15000, 15000, false));
		containers.add(new Container("sugar", 8000, 8000, false));
	}
	
	
	Container getContainerByName(String name) {
		Container container1 = null;
		for (Container container : containers) {
			if(container.getName().equalsIgnoreCase(name)) {
				container1 = container;
				break;
			}
		}
		return container1;
	}
	
	List<Container> getContainerStatus() {
		return containers;
	}

}
