package com.yash.demo;

public class Container {
	
	private String name;
	
	private double maxCapacity;
	
	private double currentAvailability;
	
	private boolean isUnderflow;
	
	public Container() {
		// TODO Auto-generated constructor stub
	}

	public Container(String name, double maxCapacity, double currentAvailability, boolean isUnderflow) {
		super();
		this.name = name;
		this.maxCapacity = maxCapacity;
		this.currentAvailability = currentAvailability;
		this.isUnderflow = isUnderflow;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMaxCapacity() {
		return maxCapacity;
	}

	public void setMaxCapacity(double maxCapacity) {
		this.maxCapacity = maxCapacity;
	}

	public double getCurrentAvailability() {
		return currentAvailability;
	}

	public void setCurrentAvailability(double currentAvailability) {
		this.currentAvailability = currentAvailability;
	}

	public boolean isUnderflow() {
		return isUnderflow;
	}

	public void setUnderflow(boolean isUnderflow) {
		this.isUnderflow = isUnderflow;
	}
}
