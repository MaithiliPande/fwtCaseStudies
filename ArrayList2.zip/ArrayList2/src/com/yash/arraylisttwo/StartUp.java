package com.yash.arraylisttwo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StartUp {

	public static void main(String[] args) {
		List<String> colorList = new ArrayList<>();
		colorList.add("Bule");
		colorList.add("Green");
		colorList.add("Red");
		colorList.add("Yellow");
		System.out.println(colorList);
		//to add at first index
		colorList.add(0, "Violet");
		System.out.println("Inserted at first index: "+colorList);
		
		//to add element at any position
		Scanner input = new Scanner(System.in);
		System.out.println("enter postion to insert element : ");
		int index = input.nextInt();
		colorList.add(index, "Pink");
		System.out.println("Inserted at any position: "+colorList);
		
		
		//to retrieve element at any position
		System.out.println("Enter index to retrieve an element :");
		int retrieveIndex = input.nextInt();
		System.out.println("Element at position :"+retrieveIndex+" is "+colorList.get(retrieveIndex));
		
		
		//to update array at specific position
		System.out.println("Enter index to update list element: ");
		int updateIndex = input.nextInt();
		System.out.println("Enter color : ");
		String updateColor = input.next();
		colorList.set(updateIndex, updateColor);
		System.out.println("Updated element at index: "+updateIndex+" is "+colorList.get(updateIndex));
		
		//to remove third element
		System.out.println("List of colors: "+colorList);
		System.out.println("Removed element: "+colorList.remove(2));
		System.out.println("List of colors after removing : "+colorList);
		
		//to search an element
		System.out.println("Enter color to search in list :");
		String searchColor = input.next();
			//method 1: using iterator
		/*Iterator<String> colorItr = colorList.iterator();
		boolean found = false;
		while (colorItr.hasNext()) {
			if(colorItr.next().equals(searchColor)) {
				found = true;
				break;
			}
		}
		String data = found?"Found "+searchColor+" at "+colorList.indexOf(searchColor):"Not found";
		System.out.println(data);*/
		
			//method2: using contains method
		if(colorList.contains(searchColor)) {
			System.out.println("Found "+searchColor+" at "+colorList.indexOf(searchColor));
		}else {
			System.out.println("Not Found");
		}
		
		input.close();
	}

}
