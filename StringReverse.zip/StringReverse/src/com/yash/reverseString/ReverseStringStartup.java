package com.yash.reverseString;

import java.util.Scanner;

public class ReverseStringStartup {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a string:");
		StringBuilder givenString = new StringBuilder(input.next());
		System.out.println("Reverse string : "+reverseString(givenString));
		input.close();
	/*	Code for Regex*/
//		 Scanner scan = new Scanner(System.in);
//	        String s = scan.nextLine();
//	        s = s.replaceAll("\\s{2,}", " ").trim();
//	        String nothing = "";
//	        if(s.equals(nothing)){
//	            System.out.println(0);
//	        }else{
//	            String[] tokenArray = s.split("[\\s,@&.?$-''!<>_]+") ;
//	            int length = tokenArray.length ;
//	            System.out.println("length"+length);
//	            for(int i = 0; i< length ; i++){
//	                System.out.println(tokenArray[i]);
//	            }
//	        }
//	        
//	        scan.close();

	}

	private static StringBuilder reverseString(StringBuilder givenString) {
		StringBuilder inputString = givenString ;
		StringBuilder reverseString = new StringBuilder();
		for(int i=inputString.length()-1;i>=0;i--) {
			reverseString = reverseString.append(inputString.charAt(i));
		}
		
		return reverseString;
	}

	

}