package com.yash.reverseString;

import java.util.Scanner;

public class ReverseStringStartup {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a string:");
		StringBuilder givenString = new StringBuilder(input.next());
		System.out.println("Reverse string : "+reverseString(givenString));		
		input.close();
	}

	private static StringBuilder reverseString(StringBuilder givenString) {
		StringBuilder inputString = givenString ;
		StringBuilder reverseString = new StringBuilder();
		for(int i=inputString.length()-1;i>=0;i--) {
			reverseString = reverseString.append(inputString.charAt(i));
		}
		return reverseString;
	}

}