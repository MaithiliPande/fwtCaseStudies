package com.yash.reverseString;

public class ReverseStringRecursion {

	public static void main(String[] args) {
		String input = "But";
		String reverse = getReverse(input);
		System.out.println("rev : "+reverse);
	}

	private static String getReverse(String input) {
		if(input.isEmpty() ) 
			return input;
 		return getReverse(input.substring(1))+input.charAt(0);
		
	}


}
