package com.yash.binarytree;

public class BinaryTree {
	
	Node root;

	public BinaryTree() {
		root = null;
	}
	
	public static void main(String[] args) {
		BinaryTree tree = new BinaryTree();
		tree.root = new Node(1);
		tree.root.left = new Node(2);
		tree.root.right = new Node(3);
		
			if(tree.root != null) {
				System.out.println(tree.root.key);
				System.out.println(tree.root.left.key);
				System.out.println(tree.root.right.key);
			}
	
		
	}
	
}
