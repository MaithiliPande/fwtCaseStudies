package com.yash.tcvm.service;

import java.util.List;

import com.yash.tcvm.enums.Ingredient;
import com.yash.tcvm.model.Container;

public interface ContainerService {
	
	Container getContainerByIngredient(Ingredient ingredient);
	
	List<Container> getContainers();

}
