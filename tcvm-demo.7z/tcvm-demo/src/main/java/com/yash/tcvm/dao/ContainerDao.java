package com.yash.tcvm.dao;

public interface ContainerDao {

}
