package com.yash.tcvm.start;

import com.yash.tcvm.builder.IDrinkBuilder;
import com.yash.tcvm.builder.TeaBuilder;
import com.yash.tcvm.enums.Drink;
import com.yash.tcvm.model.Order;

public class TestTea {
	public static void main(String[] args) {

		IDrinkBuilder drinkBuilder = TeaBuilder.getDrinkBuilder();
		
		drinkBuilder.prepareDrink(new Order(1, Drink.TEA));
		
		System.out.println("-----Report can be shown here------");
	}

}
