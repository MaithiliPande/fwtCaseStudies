package com.yash.tcvm.enums;

public enum Ingredient {
	
	SUGAR,
	TEA,
	COFFEE,
	MILK,
	WATER

}
