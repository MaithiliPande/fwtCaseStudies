package com.yash.tcvm.service;

import java.util.List;

import com.yash.tcvm.domain.Container;
import com.yash.tcvm.enumeration.Ingredient;

public interface ContainerService {

	Container getContainerByIngredient(Ingredient ingredient);
	
	List<Container> getContainerList();
}
