package com.yash.tcvm.domain;

import java.util.Date;

import com.yash.tcvm.enumeration.Drink;

public class Order {

	private int quantity;
	private Drink drink;
	private Date orderDate = new Date();
	private Boolean status;
	public Order(int quantity, Drink drink) {
		super();
		this.quantity = quantity;
		this.drink = drink;
	}
	public int getQuantity() {
		return quantity;
	}
	public Drink getDrink() {
		return drink;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public Boolean getStatus() {
		return status;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setDrink(Drink drink) {
		this.drink = drink;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	
}
