package com.yash.tcvm.main;

import java.util.Scanner;

import com.yash.tcvm.domain.Order;
import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.service.OrderService;
import com.yash.tcvm.serviceimpl.OrderServiceImpl;
import com.yash.tcvm.util.MenuUtil;

public class StartUp {

	public static void main(String[] args) {
		int choice;
		String continueChoice;
		Scanner scanner = new Scanner(System.in);
		OrderService orderService = new OrderServiceImpl();
		do {
			MenuUtil menuUtil = new MenuUtil();
			menuUtil.readFile("menu.txt");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				
				break;
			case 2:
				System.out.println("Enter number of cups:");
				int numberOfCups = scanner.nextInt();
				Order order = orderService.orderDrink(Drink.TEA,numberOfCups);
				System.out.println(order);
				break;
			case 3:

				break;
			default:
				break;
			}
			System.out.println("Do you want to continue?");
			continueChoice = scanner.next();
		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}

}
