package com.yash.tcvm.domain;

import com.yash.tcvm.enumeration.Ingredient;

public class Container {
	private Ingredient ingredient;
	private Double maxCapacity;
	private Double currentAvailability;
	public Container(Ingredient ingredient, Double maxCapacity, Double currentAvailability) {
		super();
		this.ingredient = ingredient;
		this.maxCapacity = maxCapacity;
		this.currentAvailability = currentAvailability;
	}

	public Ingredient getIngredient() {
		return ingredient;
	}

	public Double getMaxCapacity() {
		return maxCapacity;
	}
	
	public Double getCurrentAvailability() {
		return currentAvailability;
	}
	
	public void setIngredient(Ingredient ingredient) {
		this.ingredient = ingredient;
	}
	
	public void setMaxCapacity(Double maxCapacity) {
		this.maxCapacity = maxCapacity;
	}
	
	public void setCurrentAvailability(Double currentAvailability) {
		this.currentAvailability = currentAvailability;
	}
	
}
