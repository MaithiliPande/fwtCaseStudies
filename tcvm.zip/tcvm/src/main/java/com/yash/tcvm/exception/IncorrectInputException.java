package com.yash.tcvm.exception;

@SuppressWarnings("serial")
public class IncorrectInputException extends RuntimeException {
	public IncorrectInputException(String errorMessage) {
		super(errorMessage);
	}
}
