package com.yash.tcvm.congifuration;

public interface IDrinkConfiguration {
	
	public void configIngredientConsumption();
	
	public void configIngredientWastage();
	
	public void configDrinkType();
	
	public void configDrinkPrice();

}
