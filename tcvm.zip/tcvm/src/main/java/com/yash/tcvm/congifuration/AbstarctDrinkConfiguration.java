package com.yash.tcvm.congifuration;

import java.util.Map;

import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.enumeration.Ingredient;

public abstract class AbstarctDrinkConfiguration implements IDrinkConfiguration{
	
	private Map<Ingredient, Double> ingredientConsumption;
	private Map<Ingredient, Double> ingredientWastage;
	private double drinkPrice;
	private Drink drinkType;
	
	public AbstarctDrinkConfiguration() {
		initDrinkConfig();
	}
	private void initDrinkConfig() {
		 configIngredientConsumption();
		 configIngredientWastage();
		 configDrinkType();
		 configDrinkPrice();
	}
	public Map<Ingredient, Double> getIngredientConsumption() {
		return ingredientConsumption;
	}
	public Map<Ingredient, Double> getIngredientWastage() {
		return ingredientWastage;
	}
	public double getDrinkPrice() {
		return drinkPrice;
	}
	public Drink getDrinkType() {
		return drinkType;
	}
	public void setIngredientConsumption(Map<Ingredient, Double> ingredientConsumption) {
		this.ingredientConsumption = ingredientConsumption;
	}
	public void setIngredientWastage(Map<Ingredient, Double> ingredientWastage) {
		this.ingredientWastage = ingredientWastage;
	}
	public void setDrinkPrice(double drinkPrice) {
		this.drinkPrice = drinkPrice;
	}
	public void setDrinkType(Drink drinkType) {
		this.drinkType = drinkType;
	}
	// to override according to implementation
	public static IDrinkConfiguration  getDrinkConfiguration() {
		return null;
	}
	

}
