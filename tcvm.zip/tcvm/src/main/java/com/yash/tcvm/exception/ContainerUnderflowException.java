package com.yash.tcvm.exception;

@SuppressWarnings("serial")
public class ContainerUnderflowException extends RuntimeException {
	
	public ContainerUnderflowException(String errorMessage){
		super(errorMessage);
		
	}
}
