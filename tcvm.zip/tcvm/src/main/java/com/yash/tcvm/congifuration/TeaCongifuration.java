package com.yash.tcvm.congifuration;

import java.util.HashMap;

import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.enumeration.Ingredient;

public class TeaCongifuration extends AbstarctDrinkConfiguration {

	private static IDrinkConfiguration drinkConfiguration;

	public static final double WATER_CONSUMPTION = 60;
	public static final double SUGAR_CONSUMPTION = 15;
	public static final double MILK_CONSUMPTION = 40;
	public static final double TEA_CONSUMPTION = 5;
	public static final double WATER_WASTAGE = 5;
	public static final double SUGAR_WASTAGE = 2;
	public static final double MILK_WASTAGE = 4;
	public static final double TEA_WASTAGE = 1;
	public static final double PRICE = 10;

	static {
		drinkConfiguration = new TeaCongifuration();
	}

	public static IDrinkConfiguration getDrinkConfiguration() {
		return drinkConfiguration;
	}

	public void configIngredientConsumption() {
		HashMap<Ingredient, Double> ingredientConsumption = new HashMap<Ingredient, Double>();
		ingredientConsumption.put(Ingredient.MILK, MILK_CONSUMPTION);
		ingredientConsumption.put(Ingredient.WATER, WATER_CONSUMPTION);
		ingredientConsumption.put(Ingredient.TEA, TEA_CONSUMPTION);
		ingredientConsumption.put(Ingredient.SUGAR, SUGAR_CONSUMPTION);

	}

	public void configIngredientWastage() {
		HashMap<Ingredient, Double> ingredientWastage = new HashMap<Ingredient, Double>();
		ingredientWastage.put(Ingredient.MILK, MILK_WASTAGE);
		ingredientWastage.put(Ingredient.WATER, WATER_WASTAGE);
		ingredientWastage.put(Ingredient.TEA, TEA_WASTAGE);
		ingredientWastage.put(Ingredient.SUGAR, SUGAR_WASTAGE);
	}

	public void configDrinkType() {
		setDrinkType(Drink.TEA);

	}

	public void configDrinkPrice() {
		setDrinkPrice(PRICE);

	}

}
