package com.yash.tcvm.builder;

import java.util.Map;

import com.yash.tcvm.congifuration.AbstarctDrinkConfiguration;
import com.yash.tcvm.congifuration.IDrinkConfiguration;
import com.yash.tcvm.domain.Container;
import com.yash.tcvm.domain.Order;
import com.yash.tcvm.enumeration.Ingredient;
import com.yash.tcvm.exception.ContainerUnderflowException;
import com.yash.tcvm.service.ContainerService;
import com.yash.tcvm.serviceimpl.ContainerServiceImpl;

public abstract class AbstractDrinkBuilder implements IDrinkBuilder{
	
	IDrinkConfiguration drinkConfiguration;
	ContainerService containerService = new ContainerServiceImpl();
	
	public void setDrinkConfiguration(IDrinkConfiguration drinkConfiguration) {
		this.drinkConfiguration = drinkConfiguration;
	}
	
	public Order prepareDrink(Order order) {
		
		AbstarctDrinkConfiguration abstarctDrinkConfiguration = (AbstarctDrinkConfiguration) drinkConfiguration;
		Map<Ingredient, Double> consumption = abstarctDrinkConfiguration.getIngredientConsumption();
		Map<Ingredient, Double> wastage = abstarctDrinkConfiguration.getIngredientWastage();
		int numberOfCups = order.getQuantity();
		System.out.println(consumption);
		for (Map.Entry<Ingredient, Double> entry : consumption.entrySet()) {
			double quantityWasted = wastage.get(entry.getKey());
			double quantityConsumed = entry.getValue();
			Container container = containerService.getContainerByIngredient(entry.getKey());
			double quantityAvailable = container.getCurrentAvailability();
			
			if(numberOfCups*(quantityConsumed+quantityWasted)>quantityAvailable) {
				throw new ContainerUnderflowException(entry.getKey() + "Insufficient");
			}
			container.setCurrentAvailability(quantityAvailable - (numberOfCups * (quantityConsumed + quantityWasted)));

			System.out.println("Max capacity: " + container.getMaxCapacity() + " Current availability: "
					+ container.getCurrentAvailability());
			
			order.setStatus(true);
		}
		return order;
	}
	
}
