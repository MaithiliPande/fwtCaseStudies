package com.yash.tcvm.builder;

import com.yash.tcvm.congifuration.IDrinkConfiguration;
import com.yash.tcvm.domain.Order;

public interface IDrinkBuilder {

	void setDrinkConfiguration(IDrinkConfiguration drinkConfiguration);

	Order prepareDrink(Order order);
}
