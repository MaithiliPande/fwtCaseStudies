package com.yash.tcvm.builder;

import com.yash.tcvm.congifuration.TeaCongifuration;
import com.yash.tcvm.domain.Order;
import com.yash.tcvm.enumeration.Drink;


public class TeaBuilder extends AbstractDrinkBuilder{

	public TeaBuilder() {
		setDrinkConfiguration(TeaCongifuration.getDrinkConfiguration());
	}

	@Override
	public Order prepareDrink(Order order) {
		if(order.getDrink() == Drink.TEA) {
			super.prepareDrink(order);
		}else {
			throw new IllegalArgumentException("Wrong Drink Type, required "+Drink.TEA);
		}
		return order;
	}
	
	public static IDrinkBuilder getDrinkBuilder() {
		return new TeaBuilder();
	}
	
}
