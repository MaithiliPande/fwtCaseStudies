package com.yash.tcvm.serviceimpl;

import com.yash.tcvm.builder.IDrinkBuilder;
import com.yash.tcvm.builder.TeaBuilder;
import com.yash.tcvm.domain.Order;
import com.yash.tcvm.enumeration.Drink;
import com.yash.tcvm.exception.IncorrectInputException;
import com.yash.tcvm.service.OrderService;

public class OrderServiceImpl implements OrderService {

	public Order orderDrink(Drink drink, int numberOfCups) {
		IDrinkBuilder drinkBuilder = TeaBuilder.getDrinkBuilder();
		if(numberOfCups<=0) {
			throw new IncorrectInputException("Number of cups should be greater than 0");
		}
		
		return drinkBuilder.prepareDrink(new Order(numberOfCups, drink));
	}

}
