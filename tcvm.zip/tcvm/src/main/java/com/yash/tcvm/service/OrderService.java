package com.yash.tcvm.service;

import com.yash.tcvm.domain.Order;
import com.yash.tcvm.enumeration.Drink;

public interface OrderService {

	Order orderDrink(Drink drink,int numberOfCups);
}
