package com.yash.tcvm.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import com.yash.tcvm.domain.Container;
import com.yash.tcvm.enumeration.Ingredient;
import com.yash.tcvm.service.ContainerService;

public class ContainerServiceImpl implements ContainerService {
	private List<Container> containerList;

	public ContainerServiceImpl() {
		containerList = new ArrayList<Container>();
		containerList.add(new Container(Ingredient.MILK, 10000.0, 10000.0));
		containerList.add(new Container(Ingredient.TEA, 2000.0, 2000.0));
		containerList.add(new Container(Ingredient.SUGAR, 8000.0, 8000.0));
		containerList.add(new Container(Ingredient.WATER, 15000.0, 15000.0));
		containerList.add(new Container(Ingredient.COFFEE, 2000.0, 2000.0));
	}
	
	public Container getContainerByIngredient(Ingredient ingredient) {
		Container selectedContainer = null;
		for (Container container : containerList) {
			if(ingredient == container.getIngredient()) {
				selectedContainer = container;
				break;
			}
		}
		return selectedContainer;
	}
	
	public List<Container> getContainerList() {
		return containerList;
	}
	

}
