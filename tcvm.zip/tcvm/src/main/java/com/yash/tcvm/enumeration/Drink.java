package com.yash.tcvm.enumeration;

public enum Drink {
	COFFEE,
	BLACK_COFFEE,
	TEA,
	BLACK_TEA
}
