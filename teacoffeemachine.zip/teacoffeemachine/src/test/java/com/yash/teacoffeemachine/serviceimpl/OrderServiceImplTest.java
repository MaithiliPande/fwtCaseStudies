package com.yash.teacoffeemachine.serviceimpl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.yash.teacoffeemachine.dao.OrderDAO;
import com.yash.teacoffeemachine.domain.Order;
import com.yash.teacoffeemachine.enumeration.Drink;
import com.yash.teacoffeemachine.exception.EmptyListException;
import com.yash.teacoffeemachine.exception.NullObjectException;
import com.yash.teacoffeemachine.service.OrderService;

public class OrderServiceImplTest {

	OrderService orderService;
	OrderDAO orderDAO = mock(OrderDAO.class);
	Order order;

	@Before
	public void init() {
		orderService = new OrderServiceImpl(orderDAO);
	}

	@Test
	public void getOrders_ShouldReturnSizeOfOrdersList() {
		List<Order> orders = new ArrayList<>();
		orders.add(new Order(3, Drink.TEA, true));
		when(orderDAO.getOrders()).thenReturn(orders);
		assertEquals(1, orderService.getOrders().size());
	}

	@Test(expected = NullPointerException.class)
	public void getOrders_ShouldThrowNullException_WhenListReturnedIsNull() {
		List<Order> orders = null;
		when(orderDAO.getOrders()).thenReturn(orders);
		orderService.getOrders();
	}

	@Test(expected = EmptyListException.class)
	public void getOrders_ShouldThrowEmptyException_WhenListReturnedIsEmpty() {
		List<Order> orders = new ArrayList<>();
		when(orderDAO.getOrders()).thenReturn(orders);
		orderService.getOrders();
	}

	@Test
	public void getOrdersByDrink_ShouldReturnSizeOfGivenDrinkOrdersList_WhenDrinkTypeIsGiven() {
		List<Order> orders = new ArrayList<>();
		orders.add(new Order(3, Drink.TEA, true));
		when(orderDAO.getOrdersByDrink(Drink.TEA)).thenReturn(orders);
		assertEquals(1, orderService.getOrdersByDrink(Drink.TEA).size());
	}

	@Test(expected = EmptyListException.class)
	public void getOrdersByDrink_ShouldThrowEmptyException_WhenDrinkTypeIsGivenAndListReturnedIsEmpty() {
		List<Order> orders = new ArrayList<>();
		when(orderDAO.getOrdersByDrink(Drink.TEA)).thenReturn(orders);
		orderService.getOrders();
	}

	@Test(expected = NullObjectException.class)
	public void addOrder_shouldThrowNullException_WhenOrderObjectIsNull() {
		order = null;
		orderService.addOrder(order);
	}

	@Test
	public void addOrder_shouldReturnOne_whenOrderObjectIsGiven() {
		order = new Order();
		when(orderDAO.insertOrder(order)).thenReturn(1);
		assertEquals(1, orderService.addOrder(order));
	}

}
