package com.yash.teacoffeemachine.enumeration;

public enum Ingredient {
	SUGAR,TEA,COFFEE,MILK,WATER

}
