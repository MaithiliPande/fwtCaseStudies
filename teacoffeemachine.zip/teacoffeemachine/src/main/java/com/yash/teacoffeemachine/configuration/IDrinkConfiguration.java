package com.yash.teacoffeemachine.configuration;

public interface IDrinkConfiguration {

	void configIngredientConsumption();

	void configIngredientWastage();

	void configDrinkType();

	void configDrinkRate();
}
