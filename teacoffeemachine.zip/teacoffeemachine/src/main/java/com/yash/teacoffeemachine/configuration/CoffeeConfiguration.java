package com.yash.teacoffeemachine.configuration;

public class CoffeeConfiguration {
	
	

}
