package com.yash.teacoffeemachine.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.yash.teacoffeemachine.dao.ContainerDAO;
import com.yash.teacoffeemachine.domain.Container;
import com.yash.teacoffeemachine.enumeration.Ingredient;
import com.yash.teacoffeemachine.exception.NullObjectException;
import com.yash.teacoffeemachine.util.JsonUtil;

public class ContainerDAOImpl implements ContainerDAO {

	private List<Container> containers;
	private static ContainerDAOImpl containerDAOImpl = new ContainerDAOImpl();
	private JsonUtil jsonUtil = new JsonUtil();

	public ContainerDAOImpl() {
		containers = new ArrayList<Container>();
		containers.add(new Container(Ingredient.COFFE, 2000, 2000));
		containers.add(new Container(Ingredient.MILK, 10000, 10000));
		containers.add(new Container(Ingredient.SUGAR, 8000, 8000));
		containers.add(new Container(Ingredient.TEA, 2000, 2000));
		containers.add(new Container(Ingredient.WATER, 15000, 15000));
		saveContainers();
	}

	private void saveContainers() {
		jsonUtil.writeObjectToJson(containers);

	}

	public static ContainerDAOImpl getInstance() {
		return containerDAOImpl;
	}

	@Override
	public Container getContainer(Ingredient ingredient) {
		if (ingredient == null) {
			throw new NullObjectException("Ingredient Field can not be null");
		}

		return null;
	}

	@Override
	public Container updateContainer(Ingredient ingredient, Container container) {
		if (ingredient == null && container == null) {
			throw new NullObjectException("Ingredient And Container values cannot null");
		}
		Container updatedContainer = null;
		for (Container updateContainer : containers) {
			if (container.getIngredient() == ingredient) {
				updateContainer = container;
				updatedContainer = updateContainer;
				break;
			}
		}

		updateContainerToFile();
		return updatedContainer;

	}

	private void updateContainerToFile() {
		jsonUtil.writeObjectToJson(containers);
	}

	@Override
	public List<Container> getListOfContainers() {
		containers = jsonUtil.readObjectFromJson();
		return containers;
	}

}
