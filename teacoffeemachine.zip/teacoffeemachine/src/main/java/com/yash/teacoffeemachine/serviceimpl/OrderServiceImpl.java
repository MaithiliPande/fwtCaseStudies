package com.yash.teacoffeemachine.serviceimpl;

import java.util.List;

import com.yash.teacoffeemachine.builder.IDrinkBuilder;
import com.yash.teacoffeemachine.builder.TeaBuilder;
import com.yash.teacoffeemachine.dao.OrderDAO;
import com.yash.teacoffeemachine.domain.Order;
import com.yash.teacoffeemachine.enumeration.Drink;
import com.yash.teacoffeemachine.exception.NullObjectException;
import com.yash.teacoffeemachine.service.OrderService;

public class OrderServiceImpl implements OrderService {
	
	private OrderDAO orderDAO;
	
	public OrderServiceImpl(OrderDAO orderDAO) {
		this.orderDAO = orderDAO;
	}

	@Override
	public List<Order> getOrders() {
		List<Order> orders = orderDAO.getOrders();
		if(orders == null) {
			throw new NullObjectException("List of order is null");
		}
		return orders;
	}

	@Override
	public List<Order> getOrdersByDrink(Drink drink) {
		List<Order> orderList = orderDAO.getOrdersByDrink(drink);
		if(orderList == null) {
			throw new NullObjectException("Order list is null");
		}
		return orderList;
	}

	@Override
	public int addOrder(Order order) {
		IDrinkBuilder drinkBuilder;
		int rowsAffected = 0;
		if(order == null) {
			throw new NullObjectException("Order object is null");
		}
		switch (order.getDrink()) {
		case TEA:
			drinkBuilder = TeaBuilder.getDrinkBuilder();
			drinkBuilder.prepareDrink(order);
			break;
		case COFFEE:
			break;
		case BLACK_TEA:
			break;
		case BLACK_COFFEE:
			break;
			
		default:
			break;
		}
		rowsAffected = orderDAO.insertOrder(order);
		return rowsAffected;
	}

}
