package com.yash.teacoffeemachine.daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.yash.teacoffeemachine.dao.OrderDAO;
import com.yash.teacoffeemachine.domain.Order;
import com.yash.teacoffeemachine.enumeration.Drink;
import com.yash.teacoffeemachine.exception.NullObjectException;
import com.yash.teacoffeemachine.util.JsonUtil;

public class OrderDAOImpl implements OrderDAO {

	@Override
	public List<Order> getOrders() {
		List<Order> orderList = JsonUtil.readOrderJSONFromFile();
		return orderList;
	}

	@Override
	public int insertOrder(Order order) {
		int rowsAffected = 0;
		if(order == null) {
			throw new NullObjectException("Order cannot be null");
		}
		List<Order> orders = getOrders();
		if(orders == null) {
			orders = new ArrayList<Order>();
			orders.add(order);
		}
		else {
			orders.add(order);
		}
		JsonUtil.writeJSONToFile(orders);
		rowsAffected = 1;
		return rowsAffected;
	}

	@Override
	public List<Order> getOrdersByDrink(Drink drink) {
		List<Order> selectedOrders = new ArrayList<>();
		List<Order> orders = getOrders();
		if(orders.size()>0 || orders != null) {
			for (Order order : orders) {
				if(order.getDrink() == drink) {
					selectedOrders.add(order);
				}
			}
		}
		return selectedOrders;
	}
	

}
