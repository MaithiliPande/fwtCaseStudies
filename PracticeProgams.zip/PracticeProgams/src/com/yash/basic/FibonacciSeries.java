package com.yash.basic;

import java.util.Scanner;

public class FibonacciSeries {

	public static void main(String[] args) {
		int num1 = 0;
		int num2 = 1;
		int sum = 0;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a limit for fibonacci series: ");
		int limit = input.nextInt();
		System.out.println("Fibonacci Series: ");
		for(int i=1;i<=limit;i++) {
			System.out.print(sum+" ");
			sum = num1 + num2;
			num1 = num2;
			num2 = sum;
		}
		input.close();
	}
/**
 * Logic:-
 * 0,1,1,2,3,5......
 * a=0
 * b=1
 * {sum = a+b
 * a=b
 * b=sum}
 * 
 */
}
