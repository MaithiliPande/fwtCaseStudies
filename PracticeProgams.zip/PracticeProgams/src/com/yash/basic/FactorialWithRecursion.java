package com.yash.basic;

import java.util.Scanner;

/**
 * Logic for without using recursion:-
 * number=5
 * factorial = 1
 * for(number;number>1;number--){
 * 	factorial =factorial*number---------------> factorial = 1*5 here, factorail =5 --> 5*4 > 20*3 > 60*2 > 120*1
 * }
 * 
 *  
 * Using recursion :-
 * 5*4*3*2*1
 * number = 5
 * int factorial(number){
 * 	return number * factorial(number-1)----------> 5 * factorial(4) > 5*4*factorial(3) > 5*4*3*factorial(2)
 * }	
 */
public class FactorialWithRecursion {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = input.nextInt();
		System.out.println("Factorial :"+findFactorial(number));
		input.close();
	}

	private static int findFactorial(int number) {
		if(number == 0 || number == 1) {
			return 1;
		}else {
			return number * findFactorial(number-1);
		}
		
	}

}
