package com.yash.basic;

import java.util.Scanner;
/**
 * Logic :-
 * number=5
 * factorial = 1
 * for(number;number>1;number--){
 * 	factorial =factorial*number---------------> factorial = 1*5 here, factorail =5 --> 5*4 > 20*3 > 60*2 > 120*1
 * }
 */
public class FactorialWithoutRecursion {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = input.nextInt();
		long factorial = 1;
		for(int i=number; i>1; i--) {
			factorial = factorial * i ;
		}
		System.out.println("Factorial of "+number+" is : "+factorial);
		input.close();
	}
}
