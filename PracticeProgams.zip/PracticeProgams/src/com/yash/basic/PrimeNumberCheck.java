
package com.yash.basic;

import java.util.Scanner;

public class PrimeNumberCheck {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = input.nextInt();
		boolean flag = false;
		if(number == 2) flag = true;
		for(int i =2 ; i<number; i++) {
			if(number % i != 0) flag = true;
			else {
				flag = false;
				break;
			}
		}
		String result = (flag)?(number+" is a prime number"):(number+" is not a prime number");
		System.out.println(result);
		input.close();
	}
/*If you want to display all prime number from say 1 to 20,
 * then you just have to add a for loop 
 * to run this code 20 times to check every number from 1 to 20*/
}
