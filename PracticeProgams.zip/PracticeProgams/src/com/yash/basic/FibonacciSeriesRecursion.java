package com.yash.basic;

import java.util.Scanner;

public class FibonacciSeriesRecursion {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter limit :");
		int limit = input.nextInt();
		for(int i = 0; i<limit; i++) {
			System.out.print(fibonacci(i)+" ");
		}
		input.close();
	}

	private static int fibonacci(int number) {
		if(number == 0) {
			return 0;
		}else if (number ==1 ){
			return 1;
		}else {
			return fibonacci(number-1)+fibonacci(number-2);
		}
	}

}
