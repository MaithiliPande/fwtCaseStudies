package com.yash.basic;

import java.util.Scanner;

/**
 * Logic For numbers:-
 *  number =121
 *  int num = number
 *  int reverseNum
 *  while(num != 0){
 *  	int rem = num % 10;
 *  	reverseNum = reverseNum * 10 + rem
 *  	num = num /10
 *  }
 *  if(reverseNum == number){
 *  	palindrome
 *  }
 *  
 *  
 *  Logic for string
 *  String input = "nitin"
 *  String reverse = ""
 *  for(int i = input.length-1 ; i>=0; i--){
 *  	reverse = reverse + input.chaAt(i);
 *  }
 *  if(reverse.equals(input)){
 *  	palindrome
 *  }
 *
 */
public class Palindrome {

	public static void main(String[] args) {
		//for numbers
		System.out.println("Enter a number : ");
		Scanner sc = new Scanner(System.in);
		int number = sc.nextInt();
		int num = number;
		int reverse = 0;
		int rem;
		while(num != 0) {
			rem = num % 10;
			reverse = reverse*10 + rem;
			num = num /10;
		}
		if(reverse == number) {
			System.out.println("Palindrome");
		}else {
			System.out.println("Not Palindrome");
		}
		
		
		//for string
		System.out.println("Enter a string : ");
		String inputString = sc.next();
		String reverseString = "";
		for(int i = inputString.length()-1; i>=0; i--) {
			reverseString = reverseString + inputString.charAt(i); 
		}
		if(reverseString.equals(inputString))System.out.println("String is palindrome");
		else System.out.println("Not Palindrome");
		sc.close();
	}

}
