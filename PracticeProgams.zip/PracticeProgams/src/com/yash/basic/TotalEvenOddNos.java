package com.yash.basic;

import java.util.Scanner;

public class TotalEvenOddNos {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a count of total even numbers you need : ");
		int totalNumbers = input.nextInt();
		System.out.println("Even numbers");
		for(int i=0;i<totalNumbers;i++) {
			if(i%2 == 0) {
				System.out.print(i+" ");
			}
		}
		input.close();
	}

}
