package com.yash.basic;

import java.util.Scanner;

/**
 * 153 = cube(1)+cube(5)+cube(3) 
 * count no of digits first -->while(number > 0){number = number}
 */
public class ArmstrongNumber {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a number : ");
		int number = input.nextInt();
		int temp = number;
		double sum =0;
		int digits = 0;
		while(temp >0) {
			temp = temp / 10;
			digits++;
		}
		temp = number;
		for(int i=0;i<digits;i++) {
			int rem = temp % 10;
			temp = temp/10;
			sum = sum + Math.pow(rem,digits);
		}
		String data = (sum == number)?(number+" is armstrong number"):(number+" is not an armstrong nunber");
		System.out.println(data);
		input.close();
	}

}
