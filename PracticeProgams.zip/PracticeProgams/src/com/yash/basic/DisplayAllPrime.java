package com.yash.basic;

public class DisplayAllPrime {

	public static void main(String[] args) {
		int total = 30;
		for(int number=0;number<total;number++){
			boolean flag = false;
			if(number == 2) flag =true;
			for(int i = 2;i<number;i++) {
				if(number%i !=0)flag = true;
				else{
					flag = false;
					break;
				}
			}
			String result = (flag)?(number +" is a prime number"):(number +" is not a prime number");
			System.out.println(result);
		}
	}

}
