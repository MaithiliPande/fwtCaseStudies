package com.yash.mergesort;

import java.util.Arrays;

public class MergeSort {

	public static void main(String[] args) {
		int array[] = {6,5,12,10,9,1};
		System.out.println("given array : ");
		printArray(array);
		sort(array, 0, array.length-1);
		System.out.println();
		System.out.println("sorted : ");
		printArray(array);
	}

	private static void printArray(int[] array) {
		System.out.println(Arrays.toString(array));
	}

	private static void sort(int[] array, int p, int r) {
		if(p<r) {
			int q = (p+r)/2;
			sort(array, p, q);
			sort(array, q+1, r);
			merge(array,p,q,r);
		}
	}

	private static void merge(int[] array, int p, int q, int r) {
		int n1 = q-p+1; //length of first sub array
		int n2 = r-q;   //length of second sub array
		int leftArray[] = new int[n1]; //left sub array
		int rightArray[] = new int[n2]; //right sub array
		for (int i=0; i<n1 ; i++) {
			leftArray[i] = array[p+i];
		}
		for (int j=0; j<n2;j++) {
			rightArray[j] = array[q+1+j];
		}
		
		System.out.print("Left arr:");
		printArray(leftArray);
		System.out.print("Right arr:");
		printArray(rightArray);
		System.out.print("Resultant:");
		printArray(array);
		System.out.println();
		
		int i = 0;	//maintains current index of leftArray[]
		int j = 0; //maintains current index of rightArray[]
		int k=p; //maintains current index of array[p----q]
		while(i<n1 && j<n2) {
			if(leftArray[i]<=rightArray[j]) {
				array[k] = leftArray[i];
				i++;
			}else {
				array[k] = rightArray[j];
				j++;
			}
			k++;
		}
		
		while(i<n1) {
			array[k] = leftArray[i];
			i++;
			k++;
		}
		
		while(j<n2) {
			array[k]  = rightArray[j];
			j++;
			k++;
		}
	}

}
