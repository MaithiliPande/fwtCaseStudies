var taskList = {
    tasks : [],
    addTasks :function(taskDetails){
    this.tasks.push({taskDetails : taskDetails});
    },
    deleteTasks : function(position){
        this.tasks.splice(position,1);
    },
    deleteAllTasks : function(){
        this.tasks = [];
    },
    changeStatus : function(position){
        this.tasks[position].taskDetails.status = !this.tasks[position].taskDetails.status;
    }
};

var handlers = {
    displayTask : function (){
        view.displayTasks();    
    },
    addTask : function(){
      var titleInput = document.getElementById("titleInput");
      var dueDateInput = document.getElementById("dueDateInput");
        var currentDate = new Date;
        
    console.log((Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()))/(1000 * 60 * 60 * 24));
        
        var dateDiff = Math.floor((Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()) - Date.UTC(dueDateInput.value.getFullYear, dueDateInput.value.getMonth, dueDateInput.value.getDate) ) /(1000 * 60 * 60 * 24));       

        
        console.log(currentDate);
        
        console.log(dateDiff);
      var taskDetails = {
          title:titleInput.value,
          dueDate:dueDateInput.value,
          status:false};
      taskList.addTasks(taskDetails);
        titleInput.value = "";
        dueDateInput = "";
      view.displayTasks();
    },
    deleteTask : function(position){
        var checkboxes = document.getElementsByName("checkbox");
        for (index = checkboxes.length-1 ; index>=0 ; index --){
            if(checkboxes[index].checked){
                taskList.deleteTasks(index);
            }
        }
        view.displayTasks();
    },
    deleteAllTask : function(){
        taskList.deleteAllTasks();
        view.displayTasks();
    },
    changeStatus : function (){
         var checkboxes = document.getElementsByName("checkbox");
        for (index = checkboxes.length-1 ; index>=0 ; index --){
         if(checkboxes[index].checked){
            console.log(index);
            taskList.changeStatus(index);
         }
        }
        view.displayTasks();
    },
    filterTasks : function(){
        var filterInput = document.getElementById("filterInput");
        if(filterInput.value === "IN-PROGRESS"){
           var tasks = taskList.tasks.filter(checkTasksInProgress);
            return tasks;
        }
        if(filterInput.value === "COMPLETED"){
           var tasks = taskList.tasks.filter(checkTasksCompleted);
            return tasks;
        }
        if(filterInput.value === "ALL"){
            return taskList.tasks;
        }
        function filterTasksCompleted(task) {
            return task.status==true ;
        }
        function filterTasksInProgress(task) {
            return task.status==false ;
        }
    
    }
};

var view = {
    displayTasks : function(){
        var taskTable = document.querySelector("table");
        taskTable.innerHTML = "";
        var selectAll = this.createCheckBox();
        var tableTr = document.createElement("tr");
        
        var titleHead = document.createElement("th");
        titleHead.textContent = "Title";
        
        var dueDateHead = document.createElement("th");
        dueDateHead.textContent = "Due Date";
        
        var statusHead = document.createElement("th");
        statusHead.textContent = "Status";
        
        tableTr.appendChild(selectAll);
        tableTr.appendChild(titleHead);
        tableTr.appendChild(dueDateHead);
        tableTr.appendChild(statusHead);
        
        var filteredTasks = handlers.filterTasks();
       
        taskTable.appendChild(tableTr);
        for(let i=0;i<taskList.tasks.length;i++){
            var checkBox = this.createCheckBox();
            checkBox.setAttribute("id",i);
            checkBox.setAttribute("name","checkbox");
            
            var task = taskList.tasks[i].taskDetails;
            var taskTr = document.createElement("tr");
            taskTr.id = i;
            
            var titleTd = document.createElement("td");
            titleTd.textContent = task.title;
            
            var dueDateTd = document.createElement("td");
            dueDateTd.textContent = this.findDateDiff(task.dueDate);
            
            var taskStatusTd = document.createElement("td");
            
            if(task.status){
                taskStatusTd.textContent = "Completed";
            }else{
                taskStatusTd.textContent = "In Progress";
            }
            
            taskTr.append(checkBox);
            taskTr.append(titleTd);
            taskTr.append(dueDateTd);
            taskTr.append(taskStatusTd);
            taskTable.appendChild(taskTr);
        }
    },
    createCheckBox : function(){
        var checkBox = document.createElement("input");
        checkBox.type = "checkbox";
        return checkBox;
    },
    findDateDiff : function(inputDate){
        var givenDate = new Date(inputDate);
        var currentDate = new Date();
        var statusMessage = "";
        if(givenDate.getDate() === currentDate.getDate()){
            statusMessage = "Due Today";
        }else if(givenDate.getTime() > currentDate.getTime()){
            var daysLeft = givenDate.getDate() - currentDate.getDate();
            statusMessage = daysLeft+" days left";
        }else {
            statusMessage = "Overdue";
        }
        return statusMessage;
    }
};
