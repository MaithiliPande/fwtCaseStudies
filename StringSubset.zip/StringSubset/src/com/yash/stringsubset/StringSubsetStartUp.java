package com.yash.stringsubset;

public class StringSubsetStartUp {

	public static void main(String[] args) {
		String[] array1 = { "grapes"};
		String[] array2 = { "grapes"};
		System.out.println("Is Array 2 subset of Array 1?: " + findSubset(array1, array2));
	}

	private static Boolean findSubset(String[] array1, String[] array2) {
		int flag = 0;
		boolean isSubset = false;
		for (int i = 0; i <= array2.length - 1; i++) {
			flag = 0;
			for (int j = 0; j <= array1.length - 1; j++) {
				if (array1[j].equals(array2[i])) {
					flag = 1;
				}
			}
			if (flag == 0) {
				break;
			}
		}
		if (flag == 1) {
			isSubset = true;
		}
		return isSubset;
	}

}
