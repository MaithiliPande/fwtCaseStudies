package com.yash.arraylistthree;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StartUp {

	public static void main(String[] args) {
		List<String> colorList = new ArrayList<>();
		colorList.add("Green");
		colorList.add("Yellow");
		colorList.add("Blue");
		colorList.add("Pink");
		List<String> numberList = new ArrayList<>();
		numberList.add("1");
		numberList.add("2");
		numberList.add("3");
		numberList.add("4");
		//to sort the list
		Collections.sort(colorList);
		System.out.println(colorList);
		
		//to copy array list to another
		Collections.copy(colorList, numberList);
		System.out.println("Number: "+numberList);
		System.out.println("Color : "+colorList);
		
		//to shuffle list
		Collections.shuffle(numberList);
		System.out.println(numberList);
		
		//to add all elements of first list into second
		numberList.addAll(colorList);
		System.out.println(numberList);
	}

}
