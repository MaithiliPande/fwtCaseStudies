package com.yash.main;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.yash.model.Book;

public class StartUp {

	public static void main(String[] args) {
		List<Book> bookList = new ArrayList<>();
		bookList.add(new Book(1, "The alchemist", "Paulo Coelhho"));
		bookList.add(new Book(2, "The Road", "Martin"));
		bookList.add(new Book(3, "Two States", "Chetan Bhagat"));
		Iterator<Book> bookItr = bookList.iterator();
		while (bookItr.hasNext()) {
			Book book = bookItr.next();
			System.out.println(book.getId()+" Name: "+book.getName()+" Author: "+book.getAuthor());
		}
		/*You can also use for each loop instead of iterator*/
	}

}
