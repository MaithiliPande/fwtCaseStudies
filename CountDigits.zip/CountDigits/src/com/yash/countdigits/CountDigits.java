package com.yash.countdigits;

import java.util.Scanner;

public class CountDigits {

	public static void main(String[] args) {

		int number;
		int digitCount = 0;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter number:");
		try {
			number = input.nextInt();
			int tempNumber = countDigits(number, digitCount);
			System.out.println("Number of digits in " + number + " : " + tempNumber);
		}catch (Exception InputMismatchException) {
			System.out.println("Invalid input");
		}
		input.close();
	}

	private static int countDigits(int number, int digitCount) {
		int tempNumber = number;
		while (tempNumber > 0) {
			tempNumber = tempNumber / 10;
			digitCount++;
		}
		return digitCount;
	}

}
