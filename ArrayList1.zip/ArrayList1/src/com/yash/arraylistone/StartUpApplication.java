package com.yash.arraylistone;

import java.util.ArrayList;
import java.util.List;

public class StartUpApplication {

	public static void main(String[] args) {
		List<String> colorList = new ArrayList<>();
		colorList.add("Blue");
		colorList.add("Red");
		colorList.add("Green");
		colorList.add("Orange");
		// method 1: to display using for loop 
/*		for (String color : colorList) {
			System.out.println(color);
		}*/
		
		//method 2: to display using iterator
		/*Iterator<String> colorIterator = colorList.iterator();
		while(colorIterator.hasNext()) {
			System.out.println(colorIterator.next());
		}*/
		
		//method 3
		System.out.println(colorList);
	}

}
