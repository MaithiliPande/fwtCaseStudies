import java.util.Arrays;

public class SelectionSort {

	public static void main(String[] args) {
		int array[] = {5,1,12,-5,16};
		for(int i = 0; i<array.length-1; i++) {
			int index = i;
			for(int j = i+1; j<array.length-1; j++) {
				if(array[index]>array[j]) {
					index = j;
				}
			}
			int temp = array[index];
			array[index] = array[i];
			array[i] = temp;
		}
		System.out.println("Sorted Array : "+Arrays.toString(array));

	}

}
