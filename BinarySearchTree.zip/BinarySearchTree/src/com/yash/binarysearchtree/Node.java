package com.yash.binarysearchtree;

public class Node {
	int key;
	
	Node left,right;
	public Node(int item) {
		key = item;
		
		left = right = null;
	}
	
}
