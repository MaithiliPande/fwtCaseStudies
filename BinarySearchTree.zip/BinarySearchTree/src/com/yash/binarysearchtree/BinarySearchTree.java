package com.yash.binarysearchtree;

public class BinarySearchTree {
	Node root;
	
	public BinarySearchTree() {
		root = null;
	}
	public static void main(String[] args) {
		BinarySearchTree tree = new BinarySearchTree();
		tree.insert(50);
		tree.insert(40);
		tree.insert(65);
		tree.insert(34);
		tree.insert(84);
		tree.inOrder();
		tree.preOrder();
		tree.postOrder();
		tree.search(40);
		tree.search(65);
		tree.search(100);
		tree.isLeaf(34);
		tree.isLeaf(40);
		tree.isLeaf(50);
		tree.isLeaf(65);
		tree.isLeaf(84);
		
	}
	
	private void isLeaf(int key) {
		boolean isLeaf = checkLeafNode(root,key);
		String data = isLeaf ? (key+" is leaf node") : (key+" is not a leaf node");
		System.out.println(data);
		
	}
	private boolean checkLeafNode(Node root, int key) {
		boolean isLeaf = false;
		Node node = searchNode(root , key);
		if(node.left == null && node.right == null && node.key == key) {
			isLeaf = true;
			return isLeaf;
		}
		return isLeaf;
		
	}
	private void search(int key) {
		Node node = searchNode(root,key) ;
		String data = (node == null)?("Node "+key+" not found"):("Found : "+node.key);
		System.out.println(data);
	}
	private Node searchNode(Node root, int key) {
		if(root == null || root.key == key) 
			return root;
		if(key < root.key) 
			return searchNode(root.left, key);
		if(key > root.key) 
			return searchNode(root.right, key);
		return root;
	}
	private void preOrder() {
		System.out.println("PreOrder : ");
		preOrderRecord(root);
		System.out.println();
	}
	private void preOrderRecord(Node root) {
		if(root != null) {
			System.out.print(root.key+" ");
			preOrderRecord(root.left);
			preOrderRecord(root.right);
		}
	}
	private void inOrder() {
		System.out.println("InOrder: ");
		inOrderRecord(root);
		System.out.println();
	}
	private void inOrderRecord(Node root) {
		if(root != null) {
			inOrderRecord(root.left);
			System.out.print(root.key+" ");
			inOrderRecord(root.right);
		}
	}
	private void postOrder() {
		System.out.println("PostOrder : ");
		postOrderRecord(root);
		System.out.println();
	}
	private void postOrderRecord(Node root) {
		if(root != null) {
			preOrderRecord(root.left);
			preOrderRecord(root.right);
			System.out.print(root.key+" ");
		}
	}
	private void insert(int key) {
		root = insertRecord(root,key);
	}
	private Node insertRecord(Node root, int key) {
		if(root ==null) {
			root = new Node(key);
			return root;
		}
		if(key < root.key) 
			root.left = insertRecord(root.left, key);
		if(key > root.key)
			root.right = insertRecord(root.right, key);
		return root;
	}
	
}
