package com.yash.quicksort;

public class QuickSort {

	public static void main(String[] args) {
		int array[] = {10,7,3,6,1,8};
		sort(array,0,array.length-1);
		for (int i : array) {
			System.out.print(i+" ");
		}
	}

	private static void sort(int[] array, int low, int high) {
		int i = low;
		int j = high;
		int pivot = array[(low+high)/2];
		while(i<=j) {
			while(array[i]<pivot) {
				i++;
			}
			while(array[j]>pivot) {
				j--;
			}
			if(i<=j) {
				swap(array,i,j);
				System.out.println();
				i++;
				j--;
			}
		}
		if(low<j) {
			sort(array, low, j);
		}
		if(i<high) {
			sort(array, i, high);
		}
	}

	private static void swap(int[] array, int i, int j) {
		int temp = array[i];
		array[i] = array[j];
		array[j] = temp;
		for (int index : array) {
			System.out.print(index+" ");
		}
	}

}
