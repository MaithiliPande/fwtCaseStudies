package duplicateWord;

public class DuplicateWords {

	public static void main(String[] args) {
		String str = "Bread butter and bread and";
		boolean duplicate= false;
		String[] words = str.split(" ");
		for (int i = 0; i < words.length; i++) {
			for(int j = i+1; j< words.length; j++) {
				if(words[i].toLowerCase().equals(words[j].toLowerCase())) {
					duplicate=true;
					System.out.println(words[i]+" is duplicate");
				}
			}
			
		}
		if(!duplicate) {
			System.out.println("No duplicates");
		}

	}

}
