
package com.yash.binarysearch;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter an element to search : ");
		int element = input.nextInt();
		int array[] = {10,20,30,40,50};
		int first = 0;
		int last = array.length-1;
		int middle = (first+last)/2;
		int result = searchElement(array,first,last,middle,element);
		if(result == -1) {
			System.out.println("Element not found");
		}else {
			System.out.println("Element is found at position : "+result);
		}
		input.close();
	}

	private static int searchElement(int[] array, int first, int last, int middle, int element) {
		int position=-1;
		while(first<=last) {
			if(array[middle] < element) {
				first = middle+1;
			}else if (array[middle] == element) {
				return position = middle+1;
			}else {
				last = middle-1;
			}
			middle=(first+last)/2;
		}
		if(first>last) {
			return position;
		}
		return position;
	}
	
}
